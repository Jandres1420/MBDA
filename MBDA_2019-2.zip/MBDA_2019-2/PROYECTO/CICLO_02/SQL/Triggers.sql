/*Creacion Triggers Ciclo Dos*/
CREATE OR REPLACE TRIGGER ConsecutivoProve
BEFORE INSERT ON ProveedorMate
FOR EACH ROW
DECLARE
fila NUMBER;
BEGIN
    SELECT COUNT(*) INTO fila FROM ProveedorMate;
    :NEW.idProveedor:=fila+1;
END ConsecutivoProve;

CREATE OR REPLACE TRIGGER ConsecutivoTelefono
BEFORE INSERT ON Telefono 
FOR EACH ROW
DECLARE
fila NUMBER;
BEGIN
    SELECT COUNT(*) INTO fila FROM Telefono;
    :NEW.idProveedor:=fila+1;
END ConsecutivoTelefono;

CREATE OR REPLACE TRIGGER ConsecutivoSuministradoP
BEFORE INSERT ON SuministradoPor
FOR EACH ROW
DECLARE
fila NUMBER;
BEGIN
    SELECT COUNT(*) INTO fila FROM SuministradoPor;
    :NEW.idProveedor:=fila+1;
END ConsecutivoSuministrado;

CREATE OR REPLACE TRIGGER ConsecutivoSuministradoC
BEFORE INSERT ON SuministradoPor
FOR EACH ROW
DECLARE
fila NUMBER;
BEGIN
    SELECT COUNT(*) INTO fila FROM SuministradoPor;
    :NEW.idMaterial:=fila+1;
END ConsecutivoSuministradoC;

CREATE OR REPLACE TRIGGER ConsecutivoMaterialClase
BEFORE INSERT ON MaterialClase
FOR EACH ROW
DECLARE
fila NUMBER;
BEGIN
    SELECT COUNT(*) INTO fila FROM MaterialClase;
    :NEW.idMaterial:=fila+1;
END ConsecutivoMaterialClase;

CREATE OR REPLACE TRIGGER ActualizarProve
BEFORE UPDATE OF idProveedor ON ProveedorMate
BEGIN
    RAISE_APPLICATION_ERROR(-20001,'No se puede realizar la operacion');
END ActualizarProve;

CREATE OR REPLACE TRIGGER EliminarMaterial
BEFORE DELETE ON MaterialClase
FOR EACH ROW
BEGIN
    IF :old.estado!='Cambio' THEN
        RAISE_APPLICATION_ERROR(-20001,'No se puede realizar la transaccion');
    end if;
END EliminarMaterial;
