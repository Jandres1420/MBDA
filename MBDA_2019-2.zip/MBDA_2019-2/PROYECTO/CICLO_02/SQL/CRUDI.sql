CREATE OR REPLACE PACKAGE BODY PA_MATERIAL IS
    PROCEDURE AD_MATERIAL(xidMaterial IN NUMBER, xcaracteristicas IN VARCHAR2, xestado IN VARCHAR2, xrecomendaciones IN VARCHAR2) IS
    BEGIN
        INSERT INTO MaterialClase VALUES(xidMaterial,xcaracteristicas,xestado,xrecomendaciones);
    END AD_MATERIAL;

    PROCEDURE UP_MATERIAL(xidMaterial IN NUMBER,xestado IN VARCHAR2,xrecomendaciones IN VARCHAR2) IS
    BEGIN
        UPDATE MaterialClase SET estado=xestado,recomendaciones=xrecomendaciones WHERE idMaterial=xidMaterial;
    END UP_MATERIAL;

    PROCEDURE DE_MATERIAL(xidMaterial IN NUMBER) IS
    BEGIN
        DELETE FROM MaterialClase WHERE idMaterial=xidMaterial;
    END DE_MATERIAL;

    FUNCTION CO_MATERIAL(xidMaterial NUMBER) RETURN SYS_REFCURSOR IS SEÑOR SYS_REFCURSOR;
    BEGIN
        OPEN SEÑOR FOR
            SELECT idMaterial,estado FROM MaterialClase;
        RETURN SEÑOR;
    END CO_MATERIAL;
    
END PA_MATERIAL;

CREATE OR REPLACE PACKAGE BODY PA_PROVEEDOR IS
    PROCEDURE AD_PROVEEDOR(xidProveedor IN NUMBER, xnombre IN VARCHAR2, xcorreo IN VARCHAR2,xdireccion IN VARCHAR2,xdetalle IN XMLTYPE) IS
    BEGIN
        INSERT INTO ProveedorMate VALUES(xidProveedor,xnombre,xcorreo,xdireccion,xdetalle);
    END AD_PROVEEDOR;

    PROCEDURE AD_TELEFONO(xidProveedor IN NUMBER,xTeleProve IN NUMBER) IS
    BEGIN
        INSERT INTO Telefono VALUES(xidProveedor,xTeleProve);
    END AD_TELEFONO;

    PROCEDURE UP_PROVEEDOR(xidProveedor IN NUMBER, xDireccion IN VARCHAR2) IS
    BEGIN
        UPDATE  ProveedorMate SET Direccion=xDireccion WHERE idProveedor=xidProveedor;
    END UP_PROVEEDOR;

    PROCEDURE UP_TELEFONO(xidProveedor IN NUMBER, xTeleProve IN NUMBER) IS
    BEGIN
        UPDATE Telefono SET TeleProve=xTeleProve WHERE idProveedor=xidProveedor;
    END UP_TELEFONO;

    PROCEDURE DE_PROVEEDOR(xidProveedor IN NUMBER) IS
    BEGIN
        DELETE FROM ProveedorMate WHERE idProveedor=xidProveedor;
    END DE_PROVEEDOR;

    FUNCTION CO_PROVEEDOR(xidProveedor NUMBER) RETURN SYS_REFCURSOR IS SEÑOR SYS_REFCURSOR;
    BEGIN
        OPEN SEÑOR FOR
            SELECT * FROM ProveedorMate JOIN Telefono ON (ProveedorMate.idProveedor=Telefono.idProveedor);
        RETURN SEÑOR;
    END CO_PROVEEDOR;
END PA_PROVEEDOR;