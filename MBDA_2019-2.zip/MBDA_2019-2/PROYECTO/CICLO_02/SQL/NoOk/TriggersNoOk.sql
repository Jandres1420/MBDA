/*Trigger ActualizarProve*/
UPDATE ProveedorMate SET nombre = 'XBOX' WHERE nombre = 'BOXSANTI';