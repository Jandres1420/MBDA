/*Creacion de los indices del ciclo 2*/
CREATE INDEX in_estadomaterial ON MaterialClase(idMaterial,estado);
CREATE INDEX in_Telefonos ON Telefono (TeleProve);
