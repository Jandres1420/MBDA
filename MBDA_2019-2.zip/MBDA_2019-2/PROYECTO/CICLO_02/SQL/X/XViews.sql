DROP VIEW Vi_estado;
DROP VIEW Vi_proveedor;