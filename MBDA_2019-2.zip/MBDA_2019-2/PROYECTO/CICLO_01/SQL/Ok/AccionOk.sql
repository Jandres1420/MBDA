-----Eliminacion de la Clase Numero 1---
DELETE FROM Clase WHERE idCa=1;
