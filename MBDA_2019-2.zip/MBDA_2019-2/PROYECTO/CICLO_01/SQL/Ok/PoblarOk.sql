-----Clases-----
INSERT INTO clase VALUES (1,'Clase1',15,15,'LO');
INSERT INTO clase VALUES (2,'Clase2',30,20,'CM');
INSERT INTO clase VALUES (3,'Clase3',20,10,'CY');
INSERT INTO clase VALUES (4,'Clase4',15,15,'CG');
INSERT INTO clase VALUES (5,'Clase5',15,25,'LO');

-----Personal-----
INSERT INTO personal VALUES (1234567891,'Mañana');
INSERT INTO personal VALUES (1112131415,'Mañana');
INSERT INTO personal VALUES (1617181920,'Mañana');
INSERT INTO personal VALUES (2122232425,'Mañana');
INSERT INTO personal VALUES (2627282930,'Mañana');

-----Apoyo-----
INSERT INTO Apoyo VALUES ('Limpiesa',1234567891,1);
INSERT INTO Apoyo VALUES ('Recepcion',1112131415,2);
INSERT INTO Apoyo VALUES ('Limpiesa',1617181920,3);
INSERT INTO Apoyo VALUES ('Recepcion',2122232425,4);
INSERT INTO Apoyo VALUES ('Limpiesa',2627282930,5);

-----Horario-----
INSERT INTO horario VALUES (1,TO_DATE('04-10-2019','DD-MM-YYYY'),TO_TIMESTAMP('06:00','HH24:MI'),TO_TIMESTAMP('06:15','HH24:MI'),1);
INSERT INTO horario VALUES (2,TO_DATE('04-10-2019','DD-MM-YYYY'),TO_TIMESTAMP('07:00','HH24:MI'),TO_TIMESTAMP('07:30','HH24:MI'),2);
INSERT INTO horario VALUES (3,TO_DATE('04-10-2019','DD-MM-YYYY'),TO_TIMESTAMP('08:00','HH24:MI'),TO_TIMESTAMP('08:20','HH24:MI'),3);
INSERT INTO horario VALUES (4,TO_DATE('04-10-2019','DD-MM-YYYY'),TO_TIMESTAMP('09:00','HH24:MI'),TO_TIMESTAMP('09:15','HH24:MI'),4);
INSERT INTO horario VALUES (5,TO_DATE('04-10-2019','DD-MM-YYYY'),TO_TIMESTAMP('10:00','HH24:MI'),TO_TIMESTAMP('10:15','HH24:MI'),5);

-----Entrenadores-----
INSERT INTO entrenador VALUES ('LevantamientoOlimpico',1234567891,1,'
<Detalle>
    <identificacion numero=''4044404040'' tipo=''CC'' FechaNacimiento=''3/06/1998''></identificacion>
    <Nombre>Adrian</Nombre>
    <Apellido>Diaz Martinez</Apellido>
    <Estudios>
      <Colegio Nombre=''Liceo Los Angeles''></Colegio>
      <Universidad Nombre=''Area Andina'' Semestre=''8''></Universidad>
    </Estudios>
    <Especialidad>Levantamiento Olimpico</Especialidad>
</Detalle>
');
INSERT INTO entrenador VALUES ('Movilidad',1112131415,2,'
<Detalle>
    <identificacion numero=''1010127129'' tipo=''CC'' FechaNacimiento=''5/08/2000''></identificacion>
    <Nombre>Santiago</Nombre>
    <Apellido>Martinez Martinez</Apellido>
    <Estudios>
      <Colegio Nombre=''Liceo Hypatia''></Colegio>
      <Universidad Nombre=''Escuela Colombiana De Ingenieria'' Semestre=''6''></Universidad>
    </Estudios>
    <Especialidad>Gimnasia</Especialidad>
    <Premios Nombre=''Gimasia Word Champion'' Fecha=''2/02/2019''></Premios>
</Detalle>');
INSERT INTO entrenador VALUES ('Yoga',1617181920,3,
'<Detalle>
    <identificacion numero=''1010114425'' tipo=''CC'' FechaNacimiento=''26/07/1996''></identificacion>
    <Nombre>Daniel</Nombre>
    <Apellido>Martinez Martinez</Apellido>
    <Estudios>
      <Colegio Nombre=''Liceo Hypatia''></Colegio>
      <Universidad Nombre=''El Bosque''></Universidad>
    </Estudios>
    <Especialidad>Cardio</Especialidad>
</Detalle>');
INSERT INTO entrenador VALUES ('Gimnasia',2122232425,4,
'<Detalle>
    <identificacion numero=''1010145287'' tipo=''CC'' FechaNacimiento=''17/01/1993''></identificacion>
    <Nombre>Juan</Nombre>
    <Apellido>Rodriguez Vega</Apellido>
    <Estudios>
      <Colegio Nombre=''Gimnasio Del Norte''></Colegio>
      <Universidad Nombre=''SENA''></Universidad>
    </Estudios>
    <Especialidad>Levantamiento Olimpico</Especialidad>
    <Premios Nombre=''RIO 2016'' Fecha=''4/10/2016''></Premios>
</Detalle>');
INSERT INTO entrenador VALUES ('LevantamientoOlimpico',2627282930,5,
'<Detalle>
    <identificacion numero=''1015482635'' tipo=''CC'' FechaNacimiento=''7/02/1989''></identificacion>
    <Nombre>Jon</Nombre>
    <Apellido>Herrera Lopez</Apellido>
    <Estudios>
      <Colegio Nombre=''Colegio Distrital Bogota''></Colegio>
      <Universidad Nombre=''SENA''></Universidad>
    </Estudios>
    <Especialidad>Gimnasia</Especialidad>
    <Premios Nombre=''Gimasia Campeonato Bogota'' Fecha=''3/05/1999''></Premios>
</Detalle>');

-----Usuarios-----
INSERT INTO usuario VALUES (3132333435,'CC','Santiago','PE','santiago@hotmail.com','KR111',1);
INSERT INTO usuario VALUES (3637383940,'TI','Nikolas','PO','nikolas@hotmail.com','CALLE205',2);
INSERT INTO usuario VALUES (4142434445,'EX','Diego','PI','diego@hotmail.com','CALLE11KR50',3);
INSERT INTO usuario VALUES (4647484950,'CC','Angie','EG','angie@hotmail.com','CALLE100KR2',4);
INSERT INTO usuario VALUES (5152535455,'CC','Laura','PE','laura@hotmail.com','LA7CALLE100',5);

-----Suscripciones-----
INSERT INTO suscripcion VALUES (1,3132333435,'CC','PE','Pago','24',250000,'todo');
INSERT INTO suscripcion VALUES (2,3637383940,'TI','PO','NoPago','12',200000,'todo');
INSERT INTO suscripcion VALUES (3,4142434445,'EX','PI','Cancelado','3',100000,'basico');
INSERT INTO suscripcion VALUES (4,4647484950,'CC','EG','Pago','12',300000,'todo');
INSERT INTO suscripcion VALUES (5,5152535455,'CC','PE','Cancelado','24',250000,'todo');

-----Plan De Inicio-----
INSERT INTO PlanDeInicio VALUES (1,'PR');
INSERT INTO PlanDeInicio VALUES (2,'AM');
INSERT INTO PlanDeInicio VALUES (3,'BC');
INSERT INTO PlanDeInicio VALUES (4,'BC');
INSERT INTO PlanDeInicio VALUES (5,'PR');

-----Elite Gold-----
INSERT INTO EliteGold VALUES (1,5657585960);
INSERT INTO EliteGold VALUES (2,6162636465);
INSERT INTO EliteGold VALUES (3,6667686970);
INSERT INTO EliteGold VALUES (4,7172737475);
INSERT INTO EliteGold VALUES (5,7677787980);

-----Plan Espartano-----
INSERT INTO PlanEspartanos VALUES (1,1111111111,'CC');
INSERT INTO PlanEspartanos VALUES (2,2222222222,'TI');
INSERT INTO PlanEspartanos VALUES (3,3333333333,'EX');
INSERT INTO PlanEspartanos VALUES (4,4444444444,'TI');
INSERT INTO PlanEspartanos VALUES (5,5555555555,'CC');

-----Plan Olimpico-----
INSERT INTO PlanOlimpico VALUES (1,1111111111,'CC');
INSERT INTO PlanOlimpico VALUES (2,2222222222,'TI');
INSERT INTO PlanOlimpico VALUES (3,3333333333,'EX');
INSERT INTO PlanOlimpico VALUES (4,4444444444,'TI');
INSERT INTO PlanOlimpico VALUES (5,5555555555,'CC');
