/*Estos CHECKS estan unidos en el archivo Tuplas*/
ALTER TABLE Clase ADD CONSTRAINT CK_Tclass CHECK(tipo IN ('LO','CM','CY','CG'));
ALTER TABLE Clase ADD CONSTRAINT CK_duracion CHECK(duracion BETWEEN 1 AND 60);
ALTER TABLE Usuario ADD CONSTRAINT CK_correo CHECK(REGEXP_LIKE (correo, '^(\S+)\@(\S+)\.(\S+)$'));
ALTER TABLE Usuario ADD CONSTRAINT CK_Tidenti CHECK(tipoUs IN('CC','TI','EX'));
ALTER TABLE Usuario ADD CONSTRAINT CK_direccion CHECK(REGEXP_LIKE(direccion,'^[A-Z,0-9]*$'));
ALTER TABLE Usuario ADD CONSTRAINT CK_tsub CHECK(tsub IN('PE','PO','PI','EG'));
ALTER TABLE Suscripcion ADD CONSTRAINT CK_Tpay CHECK(pay IN('Pago','NoPago','Cancelado'));
ALTER TABLE Suscripcion ADD CONSTRAINT CK_tsuba CHECK(idSub IN('PE','PO','PI','EG'));
ALTER TABLE Suscripcion ADD CONSTRAINT CK_acomp2 CHECK(tipoTitular IN('CC','TI','EX'));
ALTER TABLE Suscripcion ADD CONSTRAINT CK_comple CHECK(Complemento IN('todo','basico'));
ALTER TABLE Suscripcion ADD CONSTRAINT CK_precio CHECK(precio BETWEEN 100000 AND 400000);
---------------------------------------------------------------------------------------

ALTER TABLE Entrenador ADD CONSTRAINT CK_Tespe CHECK(Especializacion IN('LevantamientoOlimpico','Yoga','Gimnasia','Movilidad'));
ALTER TABLE Personal ADD CONSTRAINT CK_Thorario CHECK(Horario IN('Mañana','Tarde'));
ALTER TABLE PlanEspartanos ADD CONSTRAINT CK_acomp1 CHECK(tipoAcompa IN('CC','TI','EX'));
ALTER TABLE PlanOlimpico ADD CONSTRAINT CK_acom CHECK(tipoAcompa IN('CC','TI','EX'));
ALTER TABLE Suscripcion ADD CONSTRAINT CK_tiempo CHECK(tiempo IN('3','12','24'));
ALTER TABLE Apoyo ADD CONSTRAINT CK_traba CHECK (tipoTraba IN('Limpiesa','Recepcion'));
