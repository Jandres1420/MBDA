CREATE TABLE Horario(
idClase NUMBER(10) NOT NULL,
fecha DATE NOT NULL,
horaInicio TIMESTAMP NOT NULL,
horaFinal TIMESTAMP NOT NULL,
clase NUMBER(10)
);

CREATE TABLE Clase(
idCa NUMBER(10),
nombre VARCHAR2(20),
duracion NUMBER(2),
cantidadCupos NUMBER(2) NOT NULL,
tipo CHAR(2) NOT NULL
);

CREATE TABLE Usuario(
idUs NUMBER(10) NOT NULL,
tipoUs CHAR(2) NOT NULL,
nombre VARCHAR2(20) NOT NULL,
tsub VARCHAR(2) NOT NULL,
correo VARCHAR2(100),
direccion VARCHAR2(100),
clase NUMBER(10)
);

CREATE TABLE Suscripcion(
numSuscripcion NUMBER(10) NOT NULL,
numTitular NUMBER(10) NOT NULL,
tipoTitular CHAR(2) NOT NULL,
idSub VARCHAR2(2) NOT NULL,
pay VARCHAR2(10) NOT NULL,
tiempo VARCHAR2(20) NOT NULL,
precio NUMBER(10) NOT NULL,
Complemento VARCHAR2(10) NOT NULL
);

CREATE TABLE PlanEspartanos(
numSuscripcion NUMBER(10) NOT NULL,
numAcompa NUMBER(10) NOT NULL,
tipoAcompa VARCHAR2(2) NOT NULL
);

CREATE TABLE PlanOlimpico(
numSuscripcion NUMBER(10) NOT NULL,
numAcompa NUMBER(10) NOT NULL,
tipoAcompa VARCHAR2(2) NOT NULL
);

CREATE TABLE PlanDeInicio(
numSuscripcion NUMBER(10) NOT NULL,
Suplemento VARCHAR2(30) NOT NULL
);

CREATE TABLE EliteGold(
numSuscripcion NUMBER(10) NOT NULL,
CuentaAho NUMBER(15) NOT NULL
);

CREATE TABLE Entrenador(
Especializacion VARCHAR2(30) NOT NULL,
idPersonal NUMBER(10) NOT NULL,
idClase NUMBER(10),
Detalle XMLTYPE NOT NULL
);

CREATE TABLE Apoyo(
TipoTraba VARCHAR2(20) NOT NULL,
idPersonal NUMBER(10) NOT NULL,
idClase NUMBER(10)
);

CREATE TABLE Personal(
idPersonal NUMBER(10) NOT NULL,
Horario VARCHAR2(10) NOT NULL
);
