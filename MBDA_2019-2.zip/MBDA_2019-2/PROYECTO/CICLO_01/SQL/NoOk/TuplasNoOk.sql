-----Clases-----
INSERT INTO clase VALUES (1,'Clase1',65,15,'KK');
INSERT INTO clase VALUES (2,'Clase2',0,20,'MM');


-----Usuarios-----
INSERT INTO usuario VALUES (3132333435,'CCD','Santiago','PE','sant@ago@hotmail.com','kr111',1);
INSERT INTO usuario VALUES (3637383940,'TID','Nikolas','POG','nikolas@hotmail.com','calle205',2);


-----Suscripciones-----
INSERT INTO suscripcion VALUES (3132333435,'CC','PE','SinPago','20',250000,'todo');
INSERT INTO suscripcion VALUES (3637383940,'TIg','POL','NoPago','12',200000,'DeTodito');
