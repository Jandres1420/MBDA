INSERT INTO entrenador VALUES ('Carrera',1234567891,1);
INSERT INTO usuario VALUES (3132333435,'CC','Andres','PE','santiago@hotmail.com',1);

/*Insertamos un nuevo usuario para comprobrar errores en PlanDeInicio y PlanOlimpico*/
INSERT INTO usuario VALUES (5555555555,'CC','Andres','PE','santiago@hotmail.com',1);
INSERT INTO PlanDeInicio VALUES (1,'HH');
INSERT INTO PlanOlimpico VALUES (2,9999999999,'SKERE');

/*Insertamos Personal para comprobrar error en Entrenador*/
INSERT INTO Personal VALUES (7777777777,'Mañana');
INSERT INTO Entrenador VALUES ('JAPON', 7777777777, 5);
