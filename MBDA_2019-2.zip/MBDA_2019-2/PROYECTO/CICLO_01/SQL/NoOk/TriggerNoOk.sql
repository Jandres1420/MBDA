/*Prueba para trigger T4_Trigger*/
UPDATE Usuario SET clave=77
WHERE idUs=1;
/*Prueba para trigger T5_Trigger*/
UPDATE Suscripcion SET clave=6565656565
WHERE numtitular=3132333435;
/*Prueba para trigger T6_Trigger*/
UPDATE Entrenador SET clave=6565656565
WHERE idPersonal=1234567891;
