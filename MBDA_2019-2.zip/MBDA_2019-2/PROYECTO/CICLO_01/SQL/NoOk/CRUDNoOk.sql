/*Pruebas fallidas para LOS PAQUETES*/
begin
PA_CLASE.AD_CLASE(1,'Clase1',15,'CLASELEVANTAMIENTO','LO');
end;

begin
PA_USUARIO.AD_USUARIO(3132333435,'CC','Santiago','PE','santiago@hotmail.com','KR111',1);
end;

begin
PA_PERSONAL.DE_PERSONAL('11111111',1);
end;