-------------BEFORE INSERT------------------


/*El primer trigger automatizara el numero de la clase el
el cual es consecutivo*/
CREATE OR REPLACE TRIGGER AutomatizacionClase
BEFORE INSERT ON Clase
REFERENCING NEW AS NEW FOR EACH ROW
DECLARE
numerofila NUMBER;
BEGIN
  SELECT COUNT(*) INTO numerofila FROM Clase;
  :new.idCa:=numerofila+1;
END AutomatizacionClase;
/*Este trigger automatiza el numero de la Clase en Horario*/
CREATE OR REPLACE TRIGGER AutomatizacionHorario
BEFORE INSERT ON Horario
REFERENCING NEW AS NEW FOR EACH ROW
DECLARE
numerofila NUMBER;
BEGIN
  SELECT COUNT(*) INTO numerofila FROM Horario;
  :new.idClase:=numerofila+1;
END AutomatizacionHorario;
/*Este trigger automatiza el numero de la clase en Entrenador*/
CREATE OR REPLACE TRIGGER AutomatizacionEntrenador
BEFORE INSERT ON Entrenador
REFERENCING NEW AS NEW FOR EACH ROW
DECLARE
numerofila NUMBER;
BEGIN
  SELECT COUNT(*) INTO numerofila FROM Entrenador;
  :new.idClase:=numerofila+1;
END AutomatizacionEntrenador;
/*Este trigger automatiza el numero de la clase en Apoyo*/
CREATE OR REPLACE TRIGGER AutomatizacionApoyo
BEFORE INSERT ON Apoyo
REFERENCING NEW AS NEW FOR EACH ROW
DECLARE
numerofila NUMBER;
BEGIN
  SELECT COUNT(*) INTO numerofila FROM Apoyo;
  :new.idClase:=numerofila+1;
END AutomatizacionApoyo;

/*La cantidad de cupos para la clase tiene que ser menor a 20*/

CREATE OR REPLACE TRIGGER CupoMaximo
BEFORE INSERT ON Clase
REFERENCING NEW AS NEW FOR EACH ROW
BEGIN
  IF :new.cantidadCupos >= 40 THEN
    RAISE_APPLICATION_ERROR(-20001,'La cantidad de cupos se excede');
  END IF;
END CupoMaximo;

/*La fecha se automatiza en la tabla Horario*/

CREATE OR REPLACE TRIGGER HorarioFecha
BEFORE INSERT ON Horario
REFERENCING NEW AS NEW FOR EACH ROW
BEGIN
  :new.fecha:=SYSDATE;
END HorarioFecha;

--------------BEFORE UPDATE-----------------
/*En Usuario solo se puede actualizar la Dirrecion, Clase,
tsub, Correo*/

CREATE OR REPLACE TRIGGER NoActualizarUsuario
BEFORE UPDATE OF idUs, tipoUs, nombre ON Usuario
BEGIN
  RAISE_APPLICATION_ERROR(-20001,'No se puede modificar esa columna');
END NoActualizarUsuario;

/*En Suscripcion no se puede modificar el numero de titular ni tampoco
el tipo de identificacion*/

CREATE OR REPLACE TRIGGER NoActualizarSuscripcion
BEFORE UPDATE OF numTitular, tipoTitular ON Suscripcion
BEGIN
  RAISE_APPLICATION_ERROR(-20001,'No se puede modificar esa columna');
END NoActualizarSuscripcion;

/*Nuevo Correo Null*/
CREATE OR REPLACE TRIGGER CorreoNULL
BEFORE UPDATE ON Usuario
FOR EACH ROW
BEGIN
  IF :NEW.correo = NULL THEN
    :NEW.correo:= :OLD.correo;
  END IF;
END CorreoNULL;

/*Si tras una actualizacion la direccion es nulo entonces se deja el anterior*/

CREATE OR REPLACE TRIGGER DireccionNULL
BEFORE UPDATE ON Usuario
FOR EACH ROW
BEGIN
  IF :NEW.direccion= NULL THEN
    :NEW.direccion:= :OLD.correo;
  END IF;
END DireccionNULL;
/*El usuario no se puede eliminar*/

CREATE OR REPLACE TRIGGER NoEliminar
BEFORE DELETE ON Suscripcion
BEGIN 
  RAISE_APPLICATION_ERROR(-20001,'No se puede eliminar');
END NoEliminar;