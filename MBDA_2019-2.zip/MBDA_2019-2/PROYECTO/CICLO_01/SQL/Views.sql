/*Vista creada para la consulta frecuente, saber en que estado esta mi suscripcion*/

CREATE VIEW Revisar_Pagos AS SELECT Usuario.idUs, usuario.nombre, pay, idSub
FROM Suscripcion JOIN Usuario ON Suscripcion.numTitular=Usuario.idUs
WHERE Usuario.idUs=3132333435;


/*Vista creada para la consulta frecuente, conocer horarios de las clases de hoy*/

CREATE OR REPLACE VIEW Consulta_Horario AS SELECT Clase.nombre, Horario.fecha, Horario.horaInicio
FROM Clase JOIN Horario ON idCa=idClase
WHERE Horario.fecha=SYSDATE ;