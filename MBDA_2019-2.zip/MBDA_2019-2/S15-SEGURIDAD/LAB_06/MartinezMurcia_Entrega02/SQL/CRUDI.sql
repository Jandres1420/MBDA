/*CRUDI de PC_REGISTROS*/
CREATE OR REPLACE PACKAGE BODY PC_Registro IS
    PROCEDURE Ad_Registro(xnumero IN NUMBER,xfecha IN DATE,xtiempo IN NUMBER,xposicion IN NUMBER,
                            xrevision IN VARCHAR2,xdificultad IN VARCHAR2,xfotos IN VARCHAR2,xcomentarios IN XMLTYPE) IS
        BEGIN
            INSERT INTO registro(numero,fecha,tiempo,posicion,revision,dificultad,fotos,comentario) VALUES (xnumero,xfecha,xtiempo,xposicion,xrevision,xdificultad,xfotos,xcomentarios);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al adicionar REGISTRO');
        END Ad_Registro;
    
    PROCEDURE Ad_Versiones(xnombre IN VARCHAR2,xfecha IN DATE) IS
        BEGIN
            INSERT INTO versiones(nombre,fecha) VALUES (xnombre,xfecha);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al adicionar VERSION');
        END Ad_Versiones;
    
    PROCEDURE Ad_Segmento(xnombre IN VARCHAR2,xtipo IN VARCHAR2,xidSegmento IN NUMBER) IS
        BEGIN
            INSERT INTO segmento(nombre,tipo,idSegmento) VALUES (xnombre,xtipo,xidSegmento);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al adicionar SEGMENTO');
        END Ad_Segmento;
    
    FUNCTION Co_Segmento(xpunto IN NUMBER) RETURN SYS_REFCURSOR IS Co_Segment SYS_REFCURSOR;
        BEGIN
            OPEN Co_Segment FOR
                SELECT * FROM segmento;
            RETURN Co_Segment;
        END Co_Segmento;
    
    FUNCTION Co_Versiones(xidEmpresa IN NUMBER,xidCiclista IN NUMBER,xidSegmento IN NUMBER) RETURN SYS_REFCURSOR IS Co_Version SYS_REFCURSOR;
        BEGIN
            OPEN Co_Version FOR
                SELECT * FROM versiones;
            RETURN Co_Version;
        END Co_Versiones;
END PC_Registro;

/*CRUDI de PC_CARRERA*/
CREATE OR REPLACE PACKAGE BODY PC_Carrera IS
    PROCEDURE Ad_Carrera(xcodigo IN NUMBER,xnombre IN VARCHAR2,xpais IN VARCHAR2,xcategotia IN VARCHAR2,xperiodicidad IN NUMBER) IS
        BEGIN
            INSERT INTO carrera(codigo,nombre,pais,categotia,periodicidad) VALUES (xcodigo,xnombre,xpais,xcategotia,xperiodicidad);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar CARRERA');
        END Ad_Carrera;
        
    PROCEDURE Ad_Punto(xorden IN NUMBER,xnombre IN VARCHAR2,xtipo IN VARCHAR2,xdistancia IN NUMBER,xtiempoLimite IN NUMBER) IS
        BEGIN
            INSERT INTO punto(orden,nombre,tipo,distancia,tiempo_limite) VALUES (xorden,xnombre,xtipo,xdistancia,xtiempoLimite);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar PUNTO');
        END Ad_Punto;
        
    PROCEDURE Ad_PropiedadDe(xporcentaje IN NUMBER) IS
        BEGIN
            INSERT INTO propiedadDe(porcentaje) VALUES (xporcentaje);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar PROPIEDADDE');
        END Ad_PropiedadDe;
        
    FUNCTION Co_Punto(xidCarr IN NUMBER) RETURN SYS_REFCURSOR IS Co_Point SYS_REFCURSOR;
        BEGIN
            OPEN Co_Point FOR
                SELECT carrera.nombre,punto.nombre FROM punto
                JOIN carrera ON carrera.codigo = punto.idCarr;
            RETURN Co_Point;
        END Co_Punto;
        
    FUNCTION Co_Miembro RETURN XMLTYPE IS Co_XML XMLTYPE;
        BEGIN
            Co_XML := dbms_xmlgen.getxmltype(
                'SELECT * FROM miembro'
            );
            RETURN Co_XML;
        END Co_Miembro;
END PC_Carrera;