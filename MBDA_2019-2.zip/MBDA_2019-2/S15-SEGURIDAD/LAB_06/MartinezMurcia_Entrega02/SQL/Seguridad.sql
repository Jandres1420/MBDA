/*Permisos para PARTICIPANTES*/
CREATE ROLE participante;

GRANT participante TO bd2158547;
GRANT participante TO bd2159965;

GRANT EXECUTE ON PA_Participante TO participante;