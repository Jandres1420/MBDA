/*PA_ADMINISTRADOR*/
CREATE OR REPLACE PACKAGE PA_Administrador IS
    PROCEDURE Ad_Miembro(xidMiembro IN NUMBER,xidt IN VARCHAR2,xidn IN NUMBER,xpais IN VARCHAR2,xcorreo IN XMLTYPE);
    PROCEDURE Ad_Persona(xnombre IN VARCHAR2);
    PROCEDURE Ad_Ciclista(xnacimiento IN VARCHAR2,xcategotia IN NUMBER);
    PROCEDURE Ad_Empresa(xrazonSocial IN VARCHAR2);
    PROCEDURE Ad_Registro(xnumero IN NUMBER,xfecha IN DATE,xtiempo IN NUMBER,xposicion IN NUMBER,
                            xrevision IN VARCHAR2,xdificultad IN VARCHAR2,xfotos IN VARCHAR2,xcomentarios IN XMLTYPE);
    PROCEDURE Ad_Versiones(xnombre IN VARCHAR2,xfecha IN DATE);
    PROCEDURE Ad_Segmento(xnombre IN VARCHAR2,xtipo IN VARCHAR2,xidSegmento IN NUMBER);
    PROCEDURE El_Miembro(xidMiembro IN NUMBER);
    PROCEDURE El_Persona(xidPersona IN NUMBER);
    PROCEDURE El_Ciclista(xidCiclista IN NUMBER);
    PROCEDURE El_Empresa(xidEmpresa IN NUMBER);
    PROCEDURE Mo_Miembro(xidMiembro IN NUMBER,xidt IN VARCHAR2,xidn IN NUMBER,xpais IN VARCHAR2,xcorreo IN VARCHAR2);
    PROCEDURE Mo_Persona(xidPersona IN NUMBER,xnombre IN VARCHAR2);
    PROCEDURE Mo_Ciclista(xidCiclista IN NUMBER,xnacimiento IN VARCHAR2,xcategotia IN NUMBER);
    PROCEDURE Mo_Empresa(xidEmpresa IN NUMBER,xrazonSocial IN VARCHAR2);
END PA_Administrador;

/*PA_PARTICIPANTE*/
CREATE OR REPLACE PACKAGE PA_Participante IS
    PROCEDURE Ad_Miembro(xidMiembro IN NUMBER,xidt IN VARCHAR2,xidn IN NUMBER,xpais IN VARCHAR2,xcorreo IN XMLTYPE);
    PROCEDURE Ad_Persona(xnombre IN VARCHAR2);
    PROCEDURE Ad_Ciclista(xnacimiento IN VARCHAR2,xcategotia IN NUMBER);
    PROCEDURE Ad_Empresa(xrazonSocial IN VARCHAR2);
    PROCEDURE Ad_Registro(xnumero IN NUMBER,xfecha IN DATE,xtiempo IN NUMBER,xposicion IN NUMBER,
                            xrevision IN VARCHAR2,xdificultad IN VARCHAR2,xfotos IN VARCHAR2,xcomentarios IN XMLTYPE);
    PROCEDURE Ad_Versiones(xnombre IN VARCHAR2,xfecha IN DATE);
    PROCEDURE Ad_Segmento(xnombre IN VARCHAR2,xtipo IN VARCHAR2,xidSegmento IN NUMBER);
    FUNCTION Co_Segmento(xpunto IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Versiones(xidEmpresa IN NUMBER,xidCiclista IN NUMBER,xidSegmento IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Punto(xidCarr IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Miembro RETURN XMLTYPE;
    FUNCTION Co_Persona(xidPersona IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Ciclista(xidCiclista IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Empresa(xidEmpresa IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Registro(xidCiclista IN NUMBER,xidVersiones IN NUMBER,xidSegmentos IN NUMBER) RETURN XMLTYPE;
END PA_Participante;