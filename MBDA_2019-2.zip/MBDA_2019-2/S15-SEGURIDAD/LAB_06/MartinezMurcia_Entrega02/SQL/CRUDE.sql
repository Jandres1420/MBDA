/*CRUDE de PC_REGISTROS*/
CREATE OR REPLACE PACKAGE PC_Registro IS
    PROCEDURE Ad_Registro(xnumero IN NUMBER,xfecha IN DATE,xtiempo IN NUMBER,xposicion IN NUMBER,
                            xrevision IN VARCHAR2,xdificultad IN VARCHAR2,xfotos IN VARCHAR2,xcomentarios IN XMLTYPE);
    PROCEDURE Ad_Versiones(xnombre IN VARCHAR2,xfecha IN DATE);
    PROCEDURE Ad_Segmento(xnombre IN VARCHAR2,xtipo IN VARCHAR2,xidSegmento IN NUMBER);
    FUNCTION Co_Segmento(xpunto IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Versiones(xidEmpresa IN NUMBER,xidCiclista IN NUMBER,xidSegmento IN NUMBER) RETURN SYS_REFCURSOR;
END PC_Registro;  

/*CRUDE de PC_CARRERA*/
CREATE OR REPLACE PACKAGE PC_Carrera IS
    PROCEDURE Ad_Carrera(xcodigo IN NUMBER,xnombre IN VARCHAR2,xpais IN VARCHAR2,xcategotia IN VARCHAR2,xperiodicidad IN NUMBER);
    PROCEDURE Ad_Punto(xorden IN NUMBER,xnombre IN VARCHAR2,xtipo IN VARCHAR2,xdistancia IN NUMBER,xtiempoLimite IN NUMBER);
    PROCEDURE Ad_PropiedadDe(xporcentaje IN NUMBER);
    FUNCTION Co_Punto(xidCarr IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION Co_Miembro RETURN XMLTYPE;
END PC_Carrera;