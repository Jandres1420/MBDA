/*Cuerpo  de PA_ADMINISTRADOR*/
CREATE OR REPLACE PACKAGE BODY PA_Administrador IS
    PROCEDURE Ad_Miembro(xidMiembro IN NUMBER,xidt IN VARCHAR2,xidn IN NUMBER,xpais IN VARCHAR2,xcorreo IN XMLTYPE) IS
        BEGIN
            INSERT INTO miembro(idMiembro,idt,idn,pais,correo) VALUES (xidMiembro,xidt,xidn,xpais,xcorreo);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar REGISTRO');
        END Ad_Miembro;
    
    PROCEDURE Ad_Persona(xnombre IN VARCHAR2) IS
        BEGIN
            INSERT INTO persona(nombre) VALUES (xnombre);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar PERSONA');
        END Ad_Persona;
        
    PROCEDURE Ad_Ciclista(xnacimiento IN VARCHAR2,xcategotia IN NUMBER) IS
        BEGIN
            INSERT INTO ciclista(nacimento,categoria) VALUES (xnacimiento,xcategotia);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar CICLISTA');
        END Ad_Ciclista;
        
    PROCEDURE Ad_Empresa(xrazonSocial IN VARCHAR2) IS
        BEGIN
            INSERT INTO empresa(razonSocial) VALUES (xrazonSocial);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar EMPRESA');
        END Ad_Empresa;
        
    PROCEDURE Ad_Registro (xnumero IN NUMBER,xfecha IN DATE,xtiempo IN NUMBER,xposicion IN NUMBER,
                            xrevision IN VARCHAR2,xdificultad IN VARCHAR2,xfotos IN VARCHAR2,xcomentarios IN XMLTYPE) IS
        BEGIN
            PC_Registro.Ad_Registro(xnumero,xfecha,xtiempo,xposicion,xrevision,xdificultad,xfotos,xcomentarios);
        END Ad_Registro;
        
    PROCEDURE Ad_Versiones(xnombre IN VARCHAR2,xfecha IN DATE) IS
        BEGIN
            PC_Registro.Ad_Versiones(xnombre,xfecha);
        END Ad_Versiones;
        
    PROCEDURE Ad_Segmento(xnombre IN VARCHAR2,xtipo IN VARCHAR2,xidSegmento IN NUMBER) IS
        BEGIN
            PC_Registro.Ad_Segmento(xnombre,xtipo,xidSegmento);
        END Ad_Segmento;
        
    PROCEDURE El_Miembro(xidMiembro IN NUMBER) IS
        BEGIN
            DELETE FROM miembro WHERE idMiembro = xidMiembro;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al eliminar MIEMBRO');
        END El_Miembro;
        
    PROCEDURE El_Persona(xidPersona IN NUMBER) IS
        BEGIN
            DELETE FROM persona WHERE idPersona = xidPersona;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al eliminar PERSONA');
        END El_Persona;
        
    PROCEDURE El_Ciclista(xidCiclista IN NUMBER) IS
        BEGIN
            DELETE FROM ciclista WHERE idCiclista = xidCiclista;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al eliminar CICLISTA');
        END El_Ciclista;
    
    PROCEDURE El_Empresa(xidEmpresa IN NUMBER) IS
        BEGIN
            DELETE FROM empresa WHERE idEmpresa = xidEmpresa;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al eliminar CICLISTA');
        END El_Empresa;
        
    PROCEDURE Mo_Miembro(xidMiembro IN NUMBER,xidt IN VARCHAR2,xidn IN NUMBER,xpais IN VARCHAR2,xcorreo IN VARCHAR2) IS
        BEGIN
            UPDATE miembro SET idMiembro = xidMiembro WHERE idt = xidt AND idn = xidn AND pais = xpais AND correo = xcorreo;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al modificar MIEMBRO');
        END Mo_Miembro;
        
    PROCEDURE Mo_Persona(xidPersona IN NUMBER,xnombre IN VARCHAR2) IS
        BEGIN
            UPDATE persona SET idPersona = xidPersona WHERE nombre = xnombre;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN 
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al modificar PERSONA');
        END Mo_Persona;
        
    PROCEDURE Mo_Ciclista(xidCiclista IN NUMBER,xnacimiento IN VARCHAR2,xcategotia IN NUMBER) IS
        BEGIN
            UPDATE ciclista SET idCiclista = xidCiclista WHERE nacimento = xnacimiento AND categoria = xcategotia;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar CICLISTA');
        END Mo_Ciclista;
    
    PROCEDURE Mo_Empresa(xidEmpresa IN NUMBER,xrazonSocial IN VARCHAR2) IS
        BEGIN
            UPDATE empresa SET idEmpresa = xidEmpresa WHERE razonSocial = xrazonSocial;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al modificar EMPRESA');
        END Mo_Empresa;
END PA_Administrador;

/*Cuerpo de PA_PARTICIPANTE*/
CREATE OR REPLACE PACKAGE BODY PA_Participante IS
    PROCEDURE Ad_Miembro(xidMiembro IN NUMBER,xidt IN VARCHAR2,xidn IN NUMBER,xpais IN VARCHAR2,xcorreo IN XMLTYPE) IS
        BEGIN
            INSERT INTO miembro(idMiembro,idt,idn,pais,correo) VALUES (xidMiembro,xidt,xidn,xpais,xcorreo);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar REGISTRO');
        END Ad_Miembro;
    
    PROCEDURE Ad_Persona(xnombre IN VARCHAR2) IS
        BEGIN
            INSERT INTO persona(nombre) VALUES (xnombre);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar PERSONA');
        END Ad_Persona;
        
    PROCEDURE Ad_Ciclista(xnacimiento IN VARCHAR2,xcategotia IN NUMBER) IS
        BEGIN
            INSERT INTO ciclista(nacimento,categoria) VALUES (xnacimiento,xcategotia);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar CICLISTA');
        END Ad_Ciclista;
        
    PROCEDURE Ad_Empresa(xrazonSocial IN VARCHAR2) IS
        BEGIN
            INSERT INTO empresa(razonSocial) VALUES (xrazonSocial);
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR(-20000,'Error al insertar EMPRESA');
        END Ad_Empresa;
        
    PROCEDURE Ad_Registro (xnumero IN NUMBER,xfecha IN DATE,xtiempo IN NUMBER,xposicion IN NUMBER,
                            xrevision IN VARCHAR2,xdificultad IN VARCHAR2,xfotos IN VARCHAR2,xcomentarios IN XMLTYPE) IS
        BEGIN
            PC_Registro.Ad_Registro(xnumero,xfecha,xtiempo,xposicion,xrevision,xdificultad,xfotos,xcomentarios);
        END Ad_Registro;
        
    PROCEDURE Ad_Versiones(xnombre IN VARCHAR2,xfecha IN DATE) IS
        BEGIN
            PC_Registro.Ad_Versiones(xnombre,xfecha);
        END Ad_Versiones;
        
    PROCEDURE Ad_Segmento(xnombre IN VARCHAR2,xtipo IN VARCHAR2,xidSegmento IN NUMBER) IS
        BEGIN
            PC_Registro.Ad_Segmento(xnombre,xtipo,xidSegmento);
        END Ad_Segmento;
        
    FUNCTION Co_Segmento(xpunto IN NUMBER) RETURN SYS_REFCURSOR IS Co_Segm SYS_REFCURSOR;
        BEGIN
            OPEN Co_Segm FOR
                SELECT * FROM segmento;
            RETURN Co_Segm;
        END Co_Segmento;
        
    FUNCTION Co_Versiones(xidEmpresa IN NUMBER,xidCiclista IN NUMBER,xidSegmento IN NUMBER) RETURN SYS_REFCURSOR IS Co_Version SYS_REFCURSOR;
        BEGIN
            OPEN Co_Version FOR
                SELECT * FROM versiones;
            RETURN Co_Version;
        END Co_Versiones;
        
    FUNCTION Co_Punto(xidCarr IN NUMBER) RETURN SYS_REFCURSOR IS Co_P SYS_REFCURSOR;
        BEGIN
            Co_P := PC_Carrera.Co_Punto(xidCarr);
            RETURN Co_P;
        END Co_Punto;
        
    FUNCTION Co_Miembro RETURN XMLTYPE IS Co_M XMLTYPE;
        BEGIN
            Co_M := PC_Carrera.Co_Miembro;
            RETURN Co_M;
        END Co_Miembro;
        
    FUNCTION Co_Persona(xidPersona IN NUMBER) RETURN SYS_REFCURSOR IS Co_Person SYS_REFCURSOR;
        BEGIN
            OPEN Co_Person FOR
                SELECT * FROM persona;
            RETURN Co_Person;
        END Co_Persona;
        
    FUNCTION Co_Ciclista(xidCiclista IN NUMBER) RETURN SYS_REFCURSOR IS Co_Ciclist SYS_REFCURSOR;
        BEGIN
            OPEN Co_Ciclist FOR
                SELECT * FROM ciclista;
            RETURN Co_Ciclist;
        END Co_Ciclista;
    
    FUNCTION Co_Empresa(xidEmpresa IN NUMBER) RETURN SYS_REFCURSOR IS Co_Emp SYS_REFCURSOR;
        BEGIN
            OPEN Co_Emp FOR
                SELECT * FROM empresa;
            RETURN Co_Emp;
        END Co_Empresa;
    
    FUNCTION Co_Registro(xidCiclista IN NUMBER,xidVersiones IN NUMBER,xidSegmentos IN NUMBER) RETURN XMLTYPE IS Co_Regist XMLTYPE;
        BEGIN
            Co_Regist := dbms_xmlgen.getxmltype(
                'SELECT * FROM registro'
            );
            RETURN Co_Regist;
        END Co_Registro;
END PA_Participante;