/*Consulta de la informacion que tiene la tabla mbda.MIEMBROS*/

SELECT * FROM MBDA.MIEMBROS;

/*Inclusion como ciclista a la tabla mbda.MIEMBROS*/

INSERT INTO MBDA.miembros VALUES('CC',1004678728,'Colombia','diego.murcia@mail.escuelaing.edu.co',NULL,'Diego Alejandro Murcia', '2000-08-22',3);
INSERT INTO MBDA.miembros VALUES('CC',1010127129,'COLOMBIA','santiago.martinez-m@mail.escuelaing.edu.co',NULL,'Santiago Martínez','2000-08-05' ,3);

/*Instrucciones necesarias para modificar o eliminar datos en la tabla mbda.MIEMBROS*/

GRANT INSERT, SELECT
ON MBDA.MIEMBROS
TO BD2159518;

/*Importar datos de la tabla mbda.MIEMBROS a nuestra base de datos*/
CREATE SEQUENCE secuencia
START with 1
increment by 1
order;

INSERT INTO MIEMBRO(idMiembro,idt,idn,pais,correo) SELECT secuencia.nextval,tipo,numero,pais,correo FROM MBDA.Miembros
                                                    WHERE razon IS NOT NULL OR nombres IS NOT NULL;

INSERT INTO persona SELECT DISTINCT miembro.idmiembro,mbda.miembros.nombres FROM Miembro
                    JOIN MBDA.Miembros ON mbda.miembros.numero = miembro.idn
                    WHERE mbda.miembros.nombres IS NOT NULL;
