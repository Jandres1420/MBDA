CREATE TABLE Miembro(
    idMiembro NUMBER,
    idt VARCHAR2(2),
    idn NUMBER,
    pais VARCHAR2(50),
    correo VARCHAR2(50)
);

CREATE TABLE Persona(
    idPersona NUMBER NOT NULL,
    nombre VARCHAR2(50) NOT NULL
);

CREATE TABLE Ciclista(
    idCiclista NUMBER,
    nacimento VARCHAR2(20),
    categoria NUMBER
);

CREATE TABLE Empresa(
    idEmpresa NUMBER,
    razonSocial VARCHAR2(50)
);

CREATE TABLE PropiedadDe(
    idmiembro NUMBER NOT NULL,
    porcentaje NUMBER NOT NULL,
    idcarrera NUMBER NOT NULL
);

CREATE TABLE Carrera(
    codigo NUMBER NOT NULL,
    nombre VARCHAR2(30),
    pais VARCHAR2(30),
    categotia VARCHAR2(30),
    periodicidad NUMBER
);

CREATE TABLE Punto(
    idCarr NUMBER NOT NULL,
    orden NUMBER NOT NULL,
    nombre VARCHAR2(10) NOT NULL,
    tipo VARCHAR2(30) NOT NULL,
    distancia NUMBER(8,2) NOT NULL,
    tiempo_limite NUMBER(30)
);

CREATE TABLE Segmento(
    nombre VARCHAR2(10) NOT NULL,
    tipo VARCHAR2(30) NOT NULL,
    idSegmento NUMBER,
    punto NUMBER NOT NULL
);

CREATE TABLE Versiones(
    nombre VARCHAR2(5) NOT NULL,
    fecha DATE NOT NULL,
    idVersiones NUMBER,
    idempresa NUMBER NOT NULL,
    idciclista NUMBER NOT NULL,
    idsegmento NUMBER NOT NULL
);

CREATE TABLE Registro(
    numero NUMBER(10) NOT NULL,
    fecha DATE NOT NULL,
    tiempo NUMBER,
    posicion NUMBER,
    revision VARCHAR2(30) NOT NULL,
    dificultad VARCHAR2(30) NOT NULL,
    fotos VARCHAR2(30),
    comentario VARCHAR2(20),
    idciclistas NUMBER,
    idversiones NUMBER,
    idsegmentos NUMBER
);

CREATE TABLE EsOrganizado(
    idempresa NUMBER NOT NULL,
    idversiones NUMBER
);

CREATE TABLE Participa(
    idciclista NUMBER NOT NULL,
    idversiones NUMBER
);

CREATE TABLE Fotos(
    numeroservicios NUMBER NOT NULL
);