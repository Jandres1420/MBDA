﻿
/*El id de la zona común se asignan automáticamente*/

CREATE OR REPLACE TRIGGER T1_ZCOMUN
BEFORE INSERT ON ZonasComunes
FOR EACH ROW
DECLARE
valorNumero INTEGER;
BEGIN 
    SELECT COUNT(*)+1 INTO valorNumero FROM ZonasComunes;
    :new.idZonaComun := valorNumero;
END;

/*Solo le puede actualizar cantidad */
CREATE OR REPLACE TRIGGER T2_ZCOMUN
BEFORE UPDATE ON ZonasComunes
FOR EACH ROW
BEGIN
    IF :new.idZonaComun <>:old.idZonaComun OR :new.horaInicio <>:old.horaInicio OR :new.horaFinal <>:old.horaFinal OR :new.tipo <>:old.tipo
    THEN
        raise_application_error(-2000021,'No se pueden actualizar');
    END IF;
END;

/*Las zonas comunes no se pueden eliminar.*/
CREATE OR REPLACE TRIGGER ZonasComunes
BEFORE DELETE ON Evaluacion
FOR EACH ROW
BEGIN
    raise_application_error(-2000021,'No se puede eliminar');
END;

/*El id de cada membresia se asigna automáticamente*/

CREATE OR REPLACE TRIGGER T1_ZCOMUN
BEFORE INSERT ON Membresias
FOR EACH ROW
DECLARE
valorNumero INTEGER;
BEGIN 
    SELECT COUNT(*)+1 INTO valorNumero FROM Membresias
    :new.idMembresia := valorNumero;
END;

/*Referencia de pago*/

CREATE OR REPLACE TRIGGER T1_ZCOMUN
BEFORE INSERT ON Pagos
FOR EACH ROW
DECLARE
valorNumero INTEGER;
BEGIN 
    SELECT COUNT(*)+1 INTO valorNumero FROM Pagos
    :new.referencia:= valorNumero;
END;


/*TDuracion*/

CREATE OR REPLACE TRIGGER T1_MEMEBRESIA
BEFORE UPDATE ON Membresias
FOR EACH ROW
DECLARE
valorDias INTEGER;
BEGIN
	SELECT fechaInicio,fechaTermina FROM Membresias 
	valorDias = isnull(COALESCE(SUM(DATEDIFF(DAY,Membresias.fechaInicio,Membresias.FechaLlegada)+1),0),0);
	:new.duracion:= valorDias;
END;

	













