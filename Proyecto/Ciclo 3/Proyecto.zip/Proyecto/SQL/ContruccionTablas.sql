------------------------------------------------------------
--Creacion de tablas

create table ZonasComunes(
    idZonaComun VARCHAR(5)  NOT NULL,
    horaInicio number NOT NULL,
    horaFinal number NOT NULL,
    capacidad number,
    tipo varchar(50)
);

create table Usuarios(
    idUsuario varchar(7) NOT NULL ,
    direccion varchar(50) NOT NULL
);

create table Registros(
    idRegistro varchar(7) NOT NULL,
    fecha date NOT NULL,
    idZonaComun varchar(3) NOT NULL ,
    duracion number NOT NULL,
    idUsuario varchar(7) NOT NULL 
);

create table Membresias(
    idMembresia INTEGER NOT NULL,
    fechaInicio date NOT NULL,
    fechaTermina date NOT NULL,
    estado  varchar(8)
);

create table MElite(
    idMembresia number NOT NULL,
    precio number NOT NULL
);

create table MPrestige(
    idMembresia number NOT NULL,
    precio number NOT NULL
);

create table MPremium(
    idMembresia  number NOT NULL,
    precio number NOT NULL
);

create table Pagos(
    metodoPago varchar(10) NOT NULL ,
    referencia varchar(3) NOT NULL,
    estado varchar(8)  NOT NULL,
    tipoPago varchar(10) NOT NULL,
    idUsuario varchar(7)  NOT NULL
);

create table PersonasElite(
    idPersonasE number NOT NULL,
    idMembresiaE number NOT NULL,
    personas varchar(50) NOT NULL,
    cantPersonas number NOT NULL
);

create table PersonasPremium(
    idPersonasE number NOT NULL,
    idMembresiaPm number NOT NULL,
    personas varchar(50) NOT NULL,
    cantPersonas number NOT NULL
);

create table PersonasPrestige(
    idPersonasE number NOT NULL,
    idMembresiaPr number NOT NULL,
    personas varchar(50) NOT NULl,
    cantPersonas number NOT NULL
);

create table UsuariosTelefonos(
    idTelefono number NOT NULL,
    idUsuario varchar(7) NOT NULL,      
    telefonos varchar(10) NOT NULL
);

create table UsuariosEmail(
    idEmail number NOT NULL,
    idUsuario varchar(7) NOT NULL,
    email varchar(50) NOT NULL 
);

create table Tiene(
    idUsuario varchar(7) NOT NULL,
    idMembresia INTEGER NOT NULL
);
