/*Eliminación de vistas*/
DROP VIEW RevisarMembresia;
DROP VIEW ConsultaRegistro;