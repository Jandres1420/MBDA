drop table ZonasComunes;
drop table Usuario;
drop table Registro;
drop table Elite;
drop table Prestige;
drop table Membresia;
drop table Premium;
drop table Pagos;