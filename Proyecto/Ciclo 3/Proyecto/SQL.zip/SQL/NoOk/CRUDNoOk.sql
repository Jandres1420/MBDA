/*pruebas fallidas para el paquete*/

BEGIN
PC_ZonasComunes.Ad_ZonaComunes(700,'1830','Canchas');
end; 

BEGIN
PC_Usuarios.Ad_Usuario(5,'Ana Gabriela Silva','1192793547','CC');
end;

BEGIN
PC_Usuarios.Ad_UsuariosEmail('anagabriela1227gmailcom');
end;