---Usuarios---
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 40 N° 485 - 27', 'Abner Christopherson', '2067641433', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 74 N° 462 - 53', 'Dyan Samson', '8040654917', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 32 N° 103 - 80', 'Theo Cicetti', '6266448324', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 55 N° 171 - 57', 'Aguste Harrill', '6686622159', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 82 N° 558 - 32', 'Paton Pinney', '5771941601', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 50 N° 238 - 59', 'Yuma Ansell', '3972985854', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 42 N° 463 - 27', 'Edyth Hitscher', '9807099920', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 16 N° 980 - 03', 'Eveleen Spedding', '6778396671', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 99 N° 857 - 80', 'Lannie Mardall', '4903631398', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 81 N° 922 - 07', 'Ada Kiss', '8167841050', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 27 N° 532 - 02', 'Fransisco Broschke', '6869870142', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 09 N° 019 - 50', 'Lazaro Bridie', '3067580446', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 32 N° 052 - 25', 'Vera Cownden', '7609008648', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 86 N° 820 - 57', 'Cassey Ingram', '7509462472', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 10 N° 140 - 23', 'Mela Venables', '9735534718', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 87 N° 987 - 13', 'Ora Prazer', '0810113636', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 22 N° 503 - 92', 'Roz Delgado', '5018026668', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 32 N° 502 - 86', 'Linette Rudyard', '0457345014', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 28 N° 997 - 75', 'Blythe BoHlingolsen', '1268143610', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 22 N° 438 - 20', 'Branden Pavlishchev', '3428799116', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 80 N° 966 - 74', 'Lisetta Shay', '7956045994', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 75 N° 436 - 74', 'Liz O''Keaveny', '3194611081', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 44 N° 497 - 02', 'Lucias Gibbens', '2886436405', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 58 N° 363 - 63', 'Leoine Antonikov', '8030038328', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 10 N° 844 - 44', 'Cherrita Kernoghan', '5742263113', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 73 N° 382 - 71', 'Marya Odom', '5276157275', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 67 N° 919 - 85', 'Othilia Summons', '2887696966', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 45 N° 219 - 31', 'Faydra Marzello', '5346072802', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 71 N° 374 - 59', 'Zonda Pennoni', '1959737312', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 81 N° 823 - 46', 'Issiah Bailey', '1920104859', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 48 N° 504 - 47', 'Andrea Claypool', '6153853881', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 07 N° 699 - 78', 'Ajay Redbourn', '3269880466', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 89 N° 516 - 48', 'Brodie Vawton', '5623244479', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 90 N° 124 - 07', 'Gabriella Woodward', '9495607134', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 17 N° 469 - 04', 'Jewel Hawe', '3634474816', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 59 N° 811 - 00', 'Annamaria Sparke', '6483392933', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 46 N° 674 - 01', 'Harold Grahlmans', '7992543690', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 69 N° 283 - 68', 'Jaymee Zeale', '5134659054', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 51 N° 889 - 56', 'Linnet Vicary', '2621950946', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 03 N° 301 - 62', 'Rosalia Brind', '9077902301', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 07 N° 509 - 72', 'Lenette Fritzer', '0170012211', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 52 N° 991 - 93', 'Jess Rebeiro', '1773740429', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 97 N° 228 - 90', 'Tiphany Cantos', '6697229984', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 86 N° 246 - 76', 'Roseanne Losbie', '7606682062', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 86 N° 031 - 93', 'Netta Traut', '1010032510', 'CC');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 58 N° 276 - 37', 'Kyla McBrearty', '7544793130', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 04 N° 284 - 02', 'Josi Deniseau', '5839012821', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 27 N° 206 - 12', 'Kermit Pratty', '0138920702', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 04 N° 200 - 70', 'Quinlan Clelle', '3767763155', 'TI');
    insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 53 N° 003 - 19', 'Lavinia Quantrell', '2108265441', 'TI');


---UsuariosTelefonos---

insert into UsuariosTelefonos ( idUsuario, telefonos) values ('1', '5312456898');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('2', '7286279685');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('3', '5689358266');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('4', '1923567347');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('5', '1704483568');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('6', '6337966672');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('7', '5914650504');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('8', '6908464689');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('9', '6989968283');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('11', '3204898552');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('12', '3015645037');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('13', '3143840241');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('14', '1323382546');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('15', '1598746328');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('16', '3102124621');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('17', '3143654820');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('18', '1314506244');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('19', '3143609112');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('20', '3124078446');

---UsuariosEmail---

insert into UsuariosEmail (idUsuario, email) values ('1', 'btower0@phoca.cz');
insert into UsuariosEmail (idUsuario, email) values ('2', 'kaire1@reuters.com');
insert into UsuariosEmail (idUsuario, email) values ('3', 'tbraisher2@nih.gov');
insert into UsuariosEmail (idUsuario, email) values ('4', 'nrickman3@census.gov');
insert into UsuariosEmail (idUsuario, email) values ('5', 'kdestoop4@nature.com');
insert into UsuariosEmail (idUsuario, email) values ('6', 'jrowbottam5@sourceforge.net');
insert into UsuariosEmail (idUsuario, email) values ('7', 'jgellett6@google.com');
insert into UsuariosEmail (idUsuario, email) values ('8', 'lpecha7@51.la');
insert into UsuariosEmail (idUsuario, email) values ('9', 'ggianullo8@boston.com');
insert into UsuariosEmail (idUsuario, email) values ('10', 'igannaway9@theguardian.com');
insert into UsuariosEmail (idUsuario, email) values ('11', 'bgabbott0@canalblog.com');
insert into UsuariosEmail (idUsuario, email) values ('12', 'fvidgeon1@purevolume.com');
insert into UsuariosEmail (idUsuario, email) values ('13', 'cfuncheon2@biglobe.ne.jp');
insert into UsuariosEmail (idUsuario, email) values ('14', 'fcurgenven3@google.ru');
insert into UsuariosEmail (idUsuario, email) values ('15', 'ekondratowicz4@utexas.edu');
insert into UsuariosEmail (idUsuario, email) values ('16', 'zjuster5@economist.com');
insert into UsuariosEmail (idUsuario, email) values ('17', 'ltattam9@rambler.ru');
insert into UsuariosEmail (idUsuario, email) values ('18', 'amcgiffieb@aol.com');
insert into UsuariosEmail (idUsuario, email) values ('19', 'mquaintancec@imgur.com');
insert into UsuariosEmail (idUsuario, email) values ('20', 'pcavyj@sfgate.com');

---Zonas Comunes---
insert into ZonasComunes (horaInicio, horaFinal, capacidad, tipo) values (700, 1830, 35, 'Gimnasio');
insert into ZonasComunes (horaInicio, horaFinal, capacidad, tipo) values (800, 1630, 27, 'Canchas');
insert into ZonasComunes (horaInicio, horaFinal, capacidad, tipo) values (830, 1730, 23, 'Zonas humedas');

---Registros---
insert into Registros (idZonaComun, duracion, idUsuario) values ('3', 1, '22');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 3, '15');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 1, '46');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 1, '10');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 2, '22');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 1, '32');
insert into Registros (idZonaComun, duracion, idUsuario) values ('3', 3, '28');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 2, '49');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 3, '30');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 1, '48');

---Membresias---

insert into Membresias (fechaInicio, fechaTermina,duracion,estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('20/01/2020','DD/MM/YYYY'),247,'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'),TO_DATE('01/02/2020','DD/MM/YYYY'),259, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('05/01/2020','DD/MM/YYYY'),232, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('17/08/2019','DD/MM/YYYY'),91, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('29/01/2020','DD/MM/YYYY'),256,'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('03/03/2020','DD/MM/YYYY'),290, 'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('02/04/2020','DD/MM/YYYY'),320, 'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('27/09/2019','DD/MM/YYYY'),132, 'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('13/09/2019','DD/MM/YYYY'),118, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('03/02/2020','DD/MM/YYYY'),261, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('22/03/2020','DD/MM/YYYY'),309, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('12/04/2020','DD/MM/YYYY'),330, 'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('13/01/2020','DD/MM/YYYY'),240, 'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('26/02/2020','DD/MM/YYYY'),284,'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('28/03/2020','DD/MM/YYYY'),315, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('26/03/2020','DD/MM/YYYY'),313, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('11/04/2020','DD/MM/YYYY'),329, 'Activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('19/01/2020','DD/MM/YYYY'),246, 'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('11/02/2020','DD/MM/YYYY'),269, 'No activa');
insert into Membresias (fechaInicio, fechaTermina,duracion,estado)  values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('17/02/2020','DD/MM/YYYY'),275, 'Activa');

--- MElite---
insert into MElite (idMembresia, cantPersonas, precio) values (1,5,350000);
insert into MElite (idMembresia, cantPersonas, precio) values (2,5,350000);
insert into MElite (idMembresia, cantPersonas, precio) values (3,5,350000);
insert into MElite (idMembresia, cantPersonas, precio) values (4,5,350000);
insert into MElite (idMembresia, cantPersonas, precio) values (5,5,350000);


---MPrestige---
insert into MPrestige (idMembresia, cantPersonas, precio) values (9,3,270000);
insert into MPrestige (idMembresia, cantPersonas, precio) values (10,3,270000);
insert into MPrestige (idMembresia, cantPersonas, precio) values (11,3,270000);

---MPremium---
insert into MPremium (idMembresia, cantPersonas, precio) values (6,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (20,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (15,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (18,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (8,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (12,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (13,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (17,1,100000);
insert into MPremium (idMembresia, cantPersonas, precio) values (16,1,100000);

---Pagos---
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','Realizado',1);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','Realizado',2);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','Realizado',3);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','Realizado',4);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','Realizado',5);
insert into Pagos (metodoPago,estado,idMembresia) values ('TDebito','Realizado',9);
insert into Pagos (metodoPago,estado,idMembresia) values ('TDebito','Realizado',10);
insert into Pagos (metodoPago,estado,idMembresia) values ('TDebito','Realizado',11);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','No realizado',6);
insert into Pagos (metodoPago,estado,idMembresia) values ('TDebito','Realizado',20);
insert into Pagos (metodoPago,estado,idMembresia) values ('TDebito','Realizado',15);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','Realizado',18);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','No realizado',8);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','No realizado',12);
insert into Pagos (metodoPago,estado,idMembresia) values ('Efectivo','No realizado',13);
insert into Pagos (metodoPago,estado,idMembresia) values ('TCredito','Realizado',17);
insert into Pagos (metodoPago,estado,idMembresia) values ('TCredito','Realizado',16);

---Personas Elite---
insert into PersonasElite(idMembresiaE,nombre) values (1,'Abner Christopherson');
insert into PersonasElite(idMembresiaE,nombre) values (2,'Dyan Samson');
insert into PersonasElite(idMembresiaE,nombre) values (3,'Theo Cicetti');
insert into PersonasElite(idMembresiaE,nombre) values (4,'Aguste Harrill');
insert into PersonasElite(idMembresiaE,nombre) values (5,'Paton Pinney');

---Personas Premium---
insert into PersonasPremium(idMembresiaPm,nombre) values (6,'Yuma Ansell');
insert into PersonasPremium(idMembresiaPm,nombre) values (20,'Edyth Hitscher');
insert into PersonasPremium(idMembresiaPm,nombre) values (15,'Eveleen Spedding');
insert into PersonasPremium(idMembresiaPm,nombre) values (18,'Lannie Mardall');
insert into PersonasPremium(idMembresiaPm,nombre) values (8,'Ada Kiss');
insert into PersonasPremium(idMembresiaPm,nombre) values (12,'Fransisco Broschke');
insert into PersonasPremium(idMembresiaPm,nombre) values (13,'Lazaro Bridie');
insert into PersonasPremium(idMembresiaPm,nombre) values (17,'Vera Cownden');
insert into PersonasPremium(idMembresiaPm,nombre) values (16,'Cassey Ingram');
---Personas Prestige---
insert into PersonasPrestige(idMembresiaPr,nombre) values (9,'Mela Venables');
insert into PersonasPrestige(idMembresiaPr,nombre) values (10,'Ora Prazer');
insert into PersonasPrestige(idMembresiaPr,nombre) values (11,'Roz Delgado');

---Usuarios Por Membresia---
insert into UsuarioMembresia(idUsuario,idMembresia) values (1,1);
insert into UsuarioMembresia(idUsuario,idMembresia) values (2,2);
insert into UsuarioMembresia(idUsuario,idMembresia) values (3,3);
insert into UsuarioMembresia(idUsuario,idMembresia) values (4,4);
insert into UsuarioMembresia(idUsuario,idMembresia) values (5,5);
insert into UsuarioMembresia(idUsuario,idMembresia) values (6,6);
insert into UsuarioMembresia(idUsuario,idMembresia) values (20,7);
insert into UsuarioMembresia(idUsuario,idMembresia) values (15,8);
insert into UsuarioMembresia(idUsuario,idMembresia) values (18,9);
insert into UsuarioMembresia(idUsuario,idMembresia) values (8,10);
insert into UsuarioMembresia(idUsuario,idMembresia) values (12,11);
insert into UsuarioMembresia(idUsuario,idMembresia) values (13,12);
insert into UsuarioMembresia(idUsuario,idMembresia) values (17,13);
insert into UsuarioMembresia(idUsuario,idMembresia) values (16,14);
insert into UsuarioMembresia(idUsuario,idMembresia) values (9,15);
insert into UsuarioMembresia(idUsuario,idMembresia) values (10,16);
insert into UsuarioMembresia(idUsuario,idMembresia) values (11,17);
















