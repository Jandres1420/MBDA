--- Eliminación de un nombre enn membresia Elite
DELETE FROM PersonasElite WHERE nombre='Abner Christopherson';
