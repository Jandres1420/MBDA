/*Índice para la búsqueda rápida de usurio*/
CREATE INDEX Idocumento ON Usuarios(nDocumento);

