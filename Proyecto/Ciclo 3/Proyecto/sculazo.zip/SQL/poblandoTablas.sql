---Usuarios---
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 40 N° 485 - 27', 'Abner Christopherson', '2067641433', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 74 N° 462 - 53', 'Dyan Samson', '8040654917', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 32 N° 103 - 80', 'Theo Cicetti', '6266448324', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 55 N° 171 - 57', 'Aguste Harrill', '6686622159', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 82 N° 558 - 32', 'Paton Pinney', '5771941601', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 50 N° 238 - 59', 'Yuma Ansell', '3972985854', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 42 N° 463 - 27', 'Edyth Hitscher', '9807099920', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 16 N° 980 - 03', 'Eveleen Spedding', '6778396671', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 99 N° 857 - 80', 'Lannie Mardall', '4903631398', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 81 N° 922 - 07', 'Ada Kiss', '8167841050', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 27 N° 532 - 02', 'Fransisco Broschke', '6869870142', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 09 N° 019 - 50', 'Lazaro Bridie', '3067580446', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 32 N° 052 - 25', 'Vera Cownden', '7609008648', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 86 N° 820 - 57', 'Cassey Ingram', '7509462472', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 10 N° 140 - 23', 'Mela Venables', '9735534718', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 87 N° 987 - 13', 'Ora Prazer', '0810113636', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 22 N° 503 - 92', 'Roz Delgado', '5018026668', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 32 N° 502 - 86', 'Linette Rudyard', '0457345014', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 28 N° 997 - 75', 'Blythe BoHlingolsen', '1268143610', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 22 N° 438 - 20', 'Branden Pavlishchev', '3428799116', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 80 N° 966 - 74', 'Lisetta Shay', '7956045994', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 75 N° 436 - 74', 'Liz O''Keaveny', '3194611081', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 44 N° 497 - 02', 'Lucias Gibbens', '2886436405', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 58 N° 363 - 63', 'Leoine Antonikov', '8030038328', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 10 N° 844 - 44', 'Cherrita Kernoghan', '5742263113', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 73 N° 382 - 71', 'Marya Odom', '5276157275', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 67 N° 919 - 85', 'Othilia Summons', '2887696966', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 45 N° 219 - 31', 'Faydra Marzello', '5346072802', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 71 N° 374 - 59', 'Zonda Pennoni', '1959737312', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 81 N° 823 - 46', 'Issiah Bailey', '1920104859', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 48 N° 504 - 47', 'Andrea Claypool', '6153853881', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 07 N° 699 - 78', 'Ajay Redbourn', '3269880466', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 89 N° 516 - 48', 'Brodie Vawton', '5623244479', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 90 N° 124 - 07', 'Gabriella Woodward', '9495607134', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 17 N° 469 - 04', 'Jewel Hawe', '3634474816', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 59 N° 811 - 00', 'Annamaria Sparke', '6483392933', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 46 N° 674 - 01', 'Harold Grahlmans', '7992543690', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 69 N° 283 - 68', 'Jaymee Zeale', '5134659054', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 51 N° 889 - 56', 'Linnet Vicary', '2621950946', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 03 N° 301 - 62', 'Rosalia Brind', '9077902301', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 07 N° 509 - 72', 'Lenette Fritzer', '0170012211', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 52 N° 991 - 93', 'Jess Rebeiro', '1773740429', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 97 N° 228 - 90', 'Tiphany Cantos', '6697229984', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 86 N° 246 - 76', 'Roseanne Losbie', '7606682062', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 86 N° 031 - 93', 'Netta Traut', '1010032510', 'CC');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 58 N° 276 - 37', 'Kyla McBrearty', '7544793130', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 04 N° 284 - 02', 'Josi Deniseau', '5839012821', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 27 N° 206 - 12', 'Kermit Pratty', '0138920702', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 04 N° 200 - 70', 'Quinlan Clelle', '3767763155', 'TI');
insert into Usuarios (direccion, nombre, nDocumento, tDocumento) values ('cra 53 N° 003 - 19', 'Lavinia Quantrell', '2108265441', 'TI');


---UsuariosTelefonos---

insert into UsuariosTelefonos ( idUsuario, telefonos) values ('30', '5312456898');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('37', '7286279685');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('36', '5689358266');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('20', '1923567347');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('22', '1704483568');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('31', '6337966672');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('4', '5914650504');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('15', '6908464689');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('2', '6989968283');
insert into UsuariosTelefonos ( idUsuario, telefonos) values ('36', '9152785678');

---UsuariosEmail---

insert into UsuariosEmail (idUsuario, email) values ('7', 'btower0@phoca.cz');
insert into UsuariosEmail (idUsuario, email) values ('19', 'kaire1@reuters.com');
insert into UsuariosEmail (idUsuario, email) values ('40', 'tbraisher2@nih.gov');
insert into UsuariosEmail (idUsuario, email) values ('14', 'nrickman3@census.gov');
insert into UsuariosEmail (idUsuario, email) values ('12', 'kdestoop4@nature.com');
insert into UsuariosEmail (idUsuario, email) values ('12', 'jrowbottam5@sourceforge.net');
insert into UsuariosEmail (idUsuario, email) values ('1', 'jgellett6@google.com');
insert into UsuariosEmail (idUsuario, email) values ('30', 'lpecha7@51.la');
insert into UsuariosEmail (idUsuario, email) values ('30', 'ggianullo8@boston.com');
insert into UsuariosEmail (idUsuario, email) values ('35', 'igannaway9@theguardian.com');

---Zonas Comunes---
insert into ZonasComunes (horaInicio, horaFinal, capacidad, tipo) values (935, 1663, 35, 'Gimnasio');
insert into ZonasComunes (horaInicio, horaFinal, capacidad, tipo) values (800, 1649, 27, 'Canchas');
insert into ZonasComunes (horaInicio, horaFinal, capacidad, tipo) values (832, 1736, 23, 'Gimnasio');

---Registros---
insert into Registros (idZonaComun, duracion, idUsuario) values ('3', 1, '22');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 3, '15');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 1, '46');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 1, '10');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 2, '22');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 1, '32');
insert into Registros (idZonaComun, duracion, idUsuario) values ('3', 3, '28');
insert into Registros (idZonaComun, duracion, idUsuario) values ('1', 2, '49');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 3, '30');
insert into Registros (idZonaComun, duracion, idUsuario) values ('2', 1, '48');

---Membresias---

insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('20/06/2020','DD/MM/YYYY'), 'Activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'),TO_DATE('01/08/2020','DD/MM/YYYY'), 'Realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('05/07/2020','DD/MM/YYYY'), 'Realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('17/10/2020','DD/MM/YYYY'), 'Realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('29/07/2020','DD/MM/YYYY'), 'No activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('03/09/2020','DD/MM/YYYY'), 'No activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('02/06/2020','DD/MM/YYYY'), 'No activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('27/10/2020','DD/MM/YYYY'), 'No activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('13/09/2020','DD/MM/YYYY'), 'Activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('03/10/2020','DD/MM/YYYY'), 'Realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('22/09/2020','DD/MM/YYYY'), 'Activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('12/09/2020','DD/MM/YYYY'), 'No realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('13/11/2020','DD/MM/YYYY'), 'No activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('26/07/2020','DD/MM/YYYY'),'No realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('28/10/2020','DD/MM/YYYY'), 'Realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('26/11/2020','DD/MM/YYYY'), 'Realizado');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('11/07/2020','DD/MM/YYYY'), 'Activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('19/09/2020','DD/MM/YYYY'), 'No activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('11/07/2020','DD/MM/YYYY'), 'No activa');
insert into Membresias (fechaInicio, fechaTermina, estado) values (TO_DATE('18/05/2019','DD/MM/YYYY'), TO_DATE('17/08/2020','DD/MM/YYYY'), 'Activa');