------------------------------------XDisparadores------------------------------------
DROP TRIGGER T1_Evaluacion;
DROP TRIGGER T2_Evaluacion;
DROP TRIGGER T3_Evaluacion;
DROP TRIGGER T4_Evaluacion;
DROP TRIGGER T5_Evaluacion;
DROP TRIGGER T1_Actividad;
DROP TRIGGER T2_Actividad;
DROP TRIGGER T3_Actividad;
DROP TRIGGER T1_Sesion;
DROP TRIGGER T2_Sesion;
DROP TRIGGER T3_Sesion;