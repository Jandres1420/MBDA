------------------------------------AccionesOK------------------------------------

insert into Participante values ('cc','119375324454698','carlos12700@gmail.com','COLOMBIA',TO_DATE('2020-01-01','YYYY/MM/DD'), null);
insert into Participante values ('cc','102982487123601','jose.perez@yahoo.com','COLOMBIA',TO_DATE('2020-01-01','YYYY/MM/DD'), null);
insert into Atleta values ('cc','119375324454698','carlos12700@gmail.com','COLOMBIA',TO_DATE('2020-01-01','YYYY/MM/DD'), null,'+','A');
insert into Entrenador values ('cc','102982487123601','jose.perez@yahoo.com','COLOMBIA',TO_DATE('2020-01-01','YYYY/MM/DD'), null,'Compensar');
insert into EntrenadoPor values ('cc','119375324454698','cc','102982487123601');