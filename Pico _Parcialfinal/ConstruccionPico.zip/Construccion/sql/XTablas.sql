--XTablas
drop table BIENES;
drop table FAMILIAS;
drop table PERSONAS;
drop table ASIGNACIONES;
drop table BIENESASIGNADOS;
drop table OPINIONES;
drop table OPINIONESGRUPALES;
drop table BIENESFAMILIAS;
